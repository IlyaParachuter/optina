
Motorola Funlight and Lighting APIs
Motorla J2ME SDK v.5.2.1
Motorola_J2ME_SDK_v5.2.1.exe
C:\Motorola\SDK v5.2.1 for J2ME\EmulatorA.1\lib\javaextensions.jar
-------------------------------------------------------------
com.motorola.Funlight.*
com.motorola.Ligting


Siemens File class
Siemens C60 emulator for SMTK2.0
c60_setup.exe
C:\siemens\SMTK\emulators\C60\lib\api.jar
-------------------------------------------------------------
com.siemens.mp.io.File       
com.siemes.mp.game.Light


JSR-75 FileConnection API, Nokia DEvice Control API, Nokia FullCanvas API
Nokia 6230i emulator
S40_DP20_SDK_6230i_installer.exe 
C:\Nokia\Devices\Nokia_S40_DP20_SDK_6230i\lib\classes.zip 
-------------------------------------------------------------
javax.microedition.io.file.*
com.nokia.mid.ui.DeviceControl.*


Samsung light API
Samsung JaUmi wireless toolkit 2.0
Installer_EA2.exe
C:\SAMSUNG_WTK20\lib\midpapi.zip 
-------------------------------------------------------------
com.samsung.util.LCDLight.class

LG Backlight API
LG Emulator
http://java.ez-i.co.kr/wire/index.asp
Town_Emulator_2.0.exe
C:\LG\Emulator\classes.zip 
-------------------------------------------------------------
mmpp.media.BackLight.class

Motorola FileConnection
Grabbed from the phone
-------------------------------------------------------------
com.motorola.io.FileConnection
com.motorola.io.FileSystemEvent
com.motorola.io.FileSystemListener
com.motorola.io.FileSystemRegistry
com.motorola.io.Registry
